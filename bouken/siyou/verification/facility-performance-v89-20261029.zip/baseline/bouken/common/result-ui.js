window.BoukenResultUI=(()=>{
 const el=(tag,cls,text)=>{const n=document.createElement(tag);n.className=cls;if(text!==undefined)n.textContent=text;return n;};
 function show(r,returnLabel='ぼうけんにもどる'){
  const abandoned=r.status==='abandoned',explored=r.status==='explored',measured=r.measurementsAvailable!==false,value=(n,unit)=>measured?n+unit:'記録なし';
  const d=el('dialog','adventure-result');d.setAttribute('aria-label','ぼうけんのリザルト');
  const header=el('header','result-hero');header.append(el('p','result-kicker','✦ ぼうけんのきろく ✦'),el('h1','',abandoned?'おつかれさま！':explored?'全マスかいたく！':'おめでとう！'),el('p','',abandoned?'ここまでの ぼうけんのきろくだよ':explored?'せかいの すべてのマスを ひらいたよ！':'マップかんぜんクリア！'));d.append(header);
  const card=title=>{const c=el('section','result-card');c.append(el('h2','',title));d.append(c);return c;};
  const world=card('ぼうけんした世界'),map=el('canvas','result-map');map.width=r.width*10;map.height=r.height*10;map.setAttribute('role','img');map.setAttribute('aria-label',r.width+'×'+r.height+(abandoned?'の冒険した地図。未発見のマスは隠しています':'のクリアした地図。赤い点は施設'));const ctx=map.getContext('2d');if(ctx){const colors={T01:'#a3d77d',T02:'#459763',T03:'#a7a9a4',T04:'#e6c979',T05:'#5da4db',T06:'#e8f5f9',T07:'#9a8bba'};r.terrain.forEach((t,i)=>{const x=i%r.width*10,y=Math.floor(i/r.width)*10;const hidden=abandoned&&!r.explored?.[i]&&!r.revealedCells?.[i];ctx.fillStyle=hidden?'#101c32':colors[t]||'#ddd';ctx.fillRect(x,y,10,10);if(r.facility[i]&&!hidden){ctx.fillStyle='#bc202a';ctx.beginPath();ctx.arc(x+5,y+5,2.7,0,Math.PI*2);ctx.fill();}if(abandoned&&!hidden&&!r.explored?.[i]){ctx.fillStyle='#101c3280';ctx.fillRect(x,y,10,10);}});}world.append(map,el('p','result-caption',r.width+' × '+r.height+' の世界　・　赤い点：施設'));
  function numbers(parent,entries){const grid=el('dl','result-numbers');for(const [name,value]of entries){const row=el('div','');row.append(el('dt','',name),el('dd','',String(value)));grid.append(row);}parent.append(grid);}
  numbers(world,[...(abandoned?[['開拓したマス',r.exploredCount+'/'+(r.width*r.height-1)+'マス']]:[]),['自力開拓',value(r.manualOpened,'マス')],['自動開拓',value(r.automaticOpened,'マス')],['透視したマス',value(r.revealed,'マス')],['訪問した施設',r.facilitiesVisited+'か所'],[abandoned||explored?'ぼうけんした時間':'クリアタイム',measured?BoukenResult.time(r.elapsedActiveMs):'記録なし']]);
  const math=card('算数のきろく');if(!measured)math.append(el('p','result-caption','この冒険の算数・時間・出会いの記録はありません。'));numbers(math,[['解いた問題',value(r.solved,'問')],['初回正解率',measured?BoukenResult.rate(r.firstTryCorrect,r.solved):'記録なし'],['最大連続正解',value(r.maxFirstTryStreak,'問')]]);const table=el('table','result-operations'),thead=el('thead',''),tr=el('tr','');['計算','問題数','初回正解率'].forEach(t=>tr.append(el('th','',t)));thead.append(tr);table.append(thead);const body=el('tbody','');for(const [key,name]of [['add','たし算'],['sub','ひき算'],['mul','かけ算'],['div','わり算']]){const op=r.byOperation[key],row=el('tr','');row.append(el('th','',name),el('td','',op.solved?op.solved+'問':'—'),el('td','',BoukenResult.rate(op.firstTryCorrect,op.solved)));body.append(row);}table.append(body);math.append(table,el('p','result-caption','最初の答えで正解できた記録だよ。'));
  const memories=card('ぼうけんの思い出');memories.append(el('p','result-caption','出会った順にならんでいるよ。👑 は初めての獲得。'));const grid=el('div','result-memories');for(const e of r.encounters){const tile=el('figure','result-memory'+(e.success?'':' failed')),pic=el('div','result-picture');tile.setAttribute('aria-label',e.name+'：'+(e.success?'獲得':'獲得できなかった')+(e.firstAcquired?'、初獲得':''));const source=e.type==='companion'?BoukenCharacterImages:BoukenItemImages;pic.append(source.picture(e.id));source.init().then(()=>pic.replaceChildren(source.picture(e.id)));tile.append(pic);if(!e.success)tile.append(el('span','result-cross','×'));if(e.firstAcquired&&e.success)tile.append(el('span','result-crown','👑'));tile.append(el('figcaption','',e.name+(e.source==='reward'?'（クリア報酬）':'')));grid.append(tile);}if(!r.encounters.length)memories.append(el('p','',measured?'この冒険では出会いがありませんでした。':'この冒険の出会いは記録されていません。'));memories.append(grid);
  if(r.robotPartReward){const part=card('ロボットの ぶひん');part.append(el('p','',r.robotPartReward.name),el('p','','ホームで ロボットに とりつけよう！'));}
  if(r.robotDiscovery){const found=card('ふしぎなもの');found.append(el('p','','あれ？ ふしぎな ものを みつけた！'),el('p','','ホームに かえって くわしく みてみよう！'));}
  const close=el('button','result-close',returnLabel);close.type='button';close.onclick=()=>d.close();d.append(close);d.addEventListener('close',()=>d.remove(),{once:true});document.body.append(d);
  if(r.robotDiscovery){
   const found=el('dialog','robot-found');found.setAttribute('aria-label','ふしぎなものを発見');
   const picture=el('div','robot-found-picture','🤖');picture.setAttribute('aria-hidden','true');
   const next=el('button','result-close','つぎへ');next.type='button';next.onclick=()=>found.close();
   found.append(el('p','result-kicker','✦ はっけん！ ✦'),picture,el('h1','','あれ？'),el('p','robot-found-copy','ふしぎな ものを みつけた！'),el('p','robot-found-copy','ホームに かえって\nくわしく みてみよう！'),next);
   found.addEventListener('close',()=>{found.remove();d.showModal();d.scrollTop=0;close.focus();},{once:true});
   document.body.append(found);found.showModal();next.focus();
  }else{d.showModal();d.scrollTop=0;}
  return d;
 }
 return Object.freeze({show});
})();
