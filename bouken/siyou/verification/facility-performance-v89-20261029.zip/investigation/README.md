# ver.89 施設訪問性能の独立調査

対象main: 4b392f8e746b4129d7b7acaa3b18032e3015b0a8。GitHub・公開環境は変更していません。

## 実行した検証

Node.js 24で `node investigation/measure.cjs`。
`baseline/bouken/` は対象コミットから取得した未変更のソース・マスターです。
`make-experiment.py` が別ファイル `world-experiment.html` を作ります。

DOMアダプターによる比較で、ブラウザの描画・レイアウト・Canvasラスタライズ・画像読込・実LocalStorageの時間は含みません。
`results.json` は同期ハンドラーと実ロジックの計測値、要素生成カウント、検証結果です。ブラウザ実測として引用しないでください。
`world-experiment.diff` が独立改善案。ブラウザ確認前の試作で、本番への適用は承認されていません。

## ブラウザでの追加調査（今回未実行）

PlaywrightとChromiumが利用できる環境で `node investigation/browser-check.cjs`。
localhost:8769専用・新規隔離コンテキストで起動し、見出しをタップして全開拓します。
本番URLにはアクセスしません。元のブラウザプロファイルを使わず、ユーザーのセーブを読み書きしません。
この補助スクリプトは未実行・動作未確認です。各サイズ1ワールドの試験なので、複数回の測定へ拡張してください。
2回のrequestAnimationFrameは描画機会までの近似であり、物理ディスプレイへの提示完了保証ではありません。

## 含まれないもの

画像素材とリポジトリ全履歴は容量のため同梱していません。ブラウザ検証には、対象コミットの `bouken/assets/` を `baseline/bouken/assets/` へ配置してください。
測定ハーネスは実マスターと実関数を使いますが、DOMは限定的な構造アダプターであり、実ブラウザと同一ではありません。
