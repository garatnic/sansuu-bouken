const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert/strict'),{performance}=require('perf_hooks'),os=require('os');
const DOM=require('./dom.cjs'),root=path.resolve(__dirname,'../baseline/bouken'),read=n=>JSON.parse(fs.readFileSync(path.join(root,'data',n+'.json'))),master=Object.fromEntries(['terrains','facilities','characters','collection_items','collection_rewards','achievements','skills','world_facility_counts'].map(n=>[n,read(n)]));
const baseline=fs.readFileSync(path.join(root,'world.html'),'utf8'),experiment=fs.readFileSync(path.join(__dirname,'world-experiment.html'),'utf8');
const slice=(s,a,b)=>{assert(s.includes(a)&&s.includes(b));return s.slice(s.indexOf(a),s.indexOf(b,s.indexOf(a)));};
function rng(seed){return ()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};}
async function context(html){
 const dom=DOM(),memory={},samples={},c={console,URL,performance,Math:Object.create(Math),document:dom.document,localStorage:{getItem:k=>memory[k]??null,setItem(k,v){if(c.failSave)throw Error('simulated quota');memory[k]=v;}},setTimeout(){},maybeShowResult(){},requestAnimationFrame(){},notify(message){this.lastNotify=message;},clock:{flush(){}},worldEnded:false,pending:null,robotRoute:[],robotDriving:false,robot:{active:false,previewing:false},adjustMapHeight(){},positionSense(){},queueTutorialReward(){},ask(){return 'question';}};c.window=c;c.notify=m=>{c.lastNotify=m;};
 c.Image=class{set src(url){if(url.includes('character_sheet')){this.naturalWidth=3840;this.naturalHeight=3968;}else if(url.includes('field_tiles')){this.naturalWidth=448;this.naturalHeight=64;}else{this.naturalWidth=512;this.naturalHeight=64;}this.onload();}};
 vm.createContext(c);
 for(const f of ['schema','party','achievements','save','collection','result','progress','explore','buffs','events','worldgen','auto-drive','tile-images','character-images','item-images','facility-event-ui'])vm.runInContext(fs.readFileSync(path.join(root,'common',f+'.js'),'utf8'),c);
 c.BoukenMaster={load:async n=>master[n]};await c.BoukenAchievements.init();c.BoukenCollection.configure(master.collection_items,master.collection_rewards);await c.BoukenTileImages.init();await c.BoukenCharacterImages.init();await c.BoukenItemImages.init();
 c.BoukenTutorial={highlightWorld:()=>false};Object.assign(c,{characters:master.characters,items:master.collection_items,facilities:master.facilities,skills:master.skills,skillNames:Object.fromEntries(master.skills.map(s=>[s.id,s.name])),tmap:Object.fromEntries(master.terrains.map(x=>[x.id,x])),fmap:Object.fromEntries(master.facilities.map(x=>[x.id,x])),colors:{},icons:{},ficons:{},map:dom.document.getElementById('map'),actions:dom.document.getElementById('actions'),info:dom.document.getElementById('info')});
 for(const id of ['visitModal','visitActions','visitTitle','visitDescription'])c[id]=dom.document.getElementById(id);
 const code=slice(html,' function persist(mutator)','\n function positionSense')+slice(html,html.includes(' let renderKeys=[];')?' let renderKeys=[];':' function render(){','\n function preloadEventImages')+slice(html,' function renderRobotRoute(){','\n function dismissRobotPlan')+slice(html,' function eventPicture(','\n async function maybeShowResult')+slice(html,' function showVisit(i)','\n document.addEventListener(\'close\'');
 c.playerIndex=()=>c.w.player.y*c.w.width+c.w.player.x;
 vm.runInContext(code,c);
 function record(k,time){(samples[k]??=[]).push(time);}
 function wrap(obj,name,label){const original=obj[name];obj[name]=function(...args){const t=performance.now();try{return original.apply(this,args);}finally{record(label,performance.now()-t);}};}
 for(const [global,names] of Object.entries({BoukenBuffs:['detected','guide','eventSense'],BoukenSave:['save'],BoukenEvents:['prepare','resolve'],BoukenProgress:['status'],BoukenAchievements:['evaluate'],BoukenCollection:['stages']})){c[global]={...c[global]};for(const n of names)wrap(c[global],n,global+'.'+n);}
 for(const n of ['render','persist','showVisit','tap','renderRobotRoute'])wrap(c,n,n);
 const oldDraw=c.BoukenTileImages.draw;c.BoukenTileImages={...c.BoukenTileImages,draw(...args){if(args[1])dom.counts.mapTileDraws=(dom.counts.mapTileDraws||0)+1;return oldDraw.apply(this,args);}};
 function reset(){for(const k of Object.keys(samples))delete samples[k];dom.reset();}
 return {c,dom,memory,samples,reset,record};
}
function seedWorld(x,n,seed,buffs=true){const c=x.c;c.Math.random=rng(seed);let save=c.BoukenSchema.makeInitialSave();save.tutorialStory.complete=true;save.worldsStarted=3;save.robotGrowth.discovery=3;save.robotGrowth.partyCapacity=5;for(const f of c.BoukenSchema.robotFeatures)save.robotGrowth.features[f.id]={stage:4};for(const ch of master.characters)save.characters[ch.id]=1;save.characterJoinOrder=master.characters.map(c=>c.id);save.party=[53,11,42,5,1];
 const w=c.BoukenWorldGen.generate(n,n,master.terrains,master.facilities,master.world_facility_counts,[]);w.departureNumber=3;w.partySnapshot=save.party;w.partyBuffsSnapshot=buffs?c.BoukenParty.buffs(save.party,new Map(master.characters.map(ch=>[ch.id,ch]))):[];c.BoukenResult.start(w);save.world=w;w.explored.fill(true);w.exploredCount=n*n-1;c.BoukenProgress.recordMilestones(save,w,undefined,master.characters);c.save=c.BoukenSave.save(save);c.w=c.save.world;c.render();c.visitModal.close();x.reset();return w.facility.map((v,i)=>v?i:-1).filter(i=>i>=0);}
const stat=arr=>({n:arr.length,mean:arr.reduce((a,b)=>a+b,0)/arr.length,max:Math.max(...arr)}),summarize=x=>Object.fromEntries(Object.entries(x).map(([k,v])=>[k,stat(v)]));
function snapshot(x){const s=JSON.parse(JSON.stringify(x.c.save));delete s.updatedAt;delete s.createdAt;if(s.world)delete s.world.createdAt;if(s.lastClearResult)delete s.lastClearResult.completedAt;return s;}
function tree(x){return JSON.stringify([x.dom.tree(x.c.map),x.dom.tree(x.dom.document.getElementById('senseGrid')),x.c.info.textContent,x.c.visitActions.textContent]);}
async function main(){
 const result={environment:{node:process.version,platform:process.platform,arch:process.arch,cpu:os.cpus()[0].model,clock:'perf_hooks.performance.now',browser:false,dom:'structural adapter; canvas drawImage is a no-op; localStorage is in-memory',sha:'4b392f8e746b4129d7b7acaa3b18032e3015b0a8',version:89},sizes:{},checks:[]};
 for(const n of [5,10,20,30]){
 const before=await context(baseline),after=await context(experiment),totals={before:{},after:{}},counts={before:[],after:[]};let operations=0;
 // Warmup is discarded; 20 fresh, identically seeded generated worlds per size.
 for(let trial=-2;trial<20;trial++){
 const indices=seedWorld(before,n,1000+n*100+trial),indices2=seedWorld(after,n,1000+n*100+trial);assert.equal(JSON.stringify(indices),JSON.stringify(indices2));
 for(const i of indices){
 for(const [label,x]of [['before',before],['after',after]]){
  x.dom.reset();let t=performance.now();x.c.tap(i);x.record('open.sync',performance.now()-t);const openCount={...x.dom.counts};assert(x.c.visitModal.open,JSON.stringify({n,trial,i,last:x.c.lastNotify,player:x.c.w.player,visited:x.c.w.visitedFacilities[i]}));x.dom.reset();t=performance.now();x.c.visitActions.children[0].onclick();x.record('confirm.sync',performance.now()-t);if(trial>=0)counts[label].push({open:openCount,confirm:{...x.dom.counts}});x.c.visitModal.close();
 }
 await Promise.resolve();assert.deepEqual(snapshot(before),snapshot(after));assert.equal(tree(before),tree(after));
 
 if(trial>=0)operations++;
 }
 for(const [label,x]of [['before',before],['after',after]]){if(trial>=0)for(const [k,v]of Object.entries(x.samples))(totals[label][k]??=[]).push(...v);x.reset();}
 }
 result.sizes[n]={worlds:20,facilityPairs:operations,before:summarize(totals.before),after:summarize(totals.after),counts};result.checks.push(`${n}x${n}: generated worlds, all facilities, same RNG stream, saves/results/DOM tree/guide/sense equal`);
 console.log(n,operations,'open',stat(totals.before['open.sync']).mean,stat(totals.after['open.sync']).mean);
 }
 // Differential render/state tests with actual module code; adapter only replaces browser APIs.
 const a=await context(baseline),b=await context(experiment);
 for(const n of [5,10,20,30]){
 seedWorld(a,n,77);seedWorld(b,n,77);
 for(const x of [a,b]){x.c.w.explored.fill(false);x.c.w.explored[x.c.w.startIndex]=true;x.c.w.visitedFacilities.fill(false);x.c.w.revealed.fill(false);x.c.robotRoute=[];x.c.render();}
 assert.equal(tree(a),tree(b));
 for(let k=0;k<Math.min(n*n,70);k++){
 for(const x of [a,b]){const c=x.c;c.w.explored[k]=true;c.w.revealed[(k+1)%(n*n)]=true;c.w.player={x:k%n,y:Math.floor(k/n)};c.robotDriving=k%2===0;c.robotRoute=[{index:(k+2)%(n*n),step:1,destination:true}];c.render();}assert.equal(tree(a),tree(b));
 }
 for(const x of [a,b]){x.c.robotRoute=[];x.c.robotDriving=false;x.c.render();x.c.save.world=x.c.w;x.c.save=x.c.BoukenSave.save(x.c.save);x.c.save=x.c.BoukenSave.load();x.c.w=x.c.save.world;x.c.render();}assert.equal(tree(a),tree(b));
 result.checks.push(`${n}x${n}: partial exploration/reveal/frontier/robot icon/route/stop/reload DOM parity`);
 }
 // F01/F02 choices, retries/extra loot: preserve exact outcomes and RNG call counts.
 for(let trial=0;trial<30;trial++){
 for(const x of [a,b]){seedWorld(x,30,9000+trial);x.c.w.partyBuffsSnapshot=['F01','F02','D07','C03','B04','B07'].map(id=>({id,level:3}));x.c.save.world=x.c.w;x.c.BoukenSave.save(x.c.save);x.c.render();}
 for(const i of a.c.w.facility.map((v,i)=>v?i:-1).filter(i=>i>=0)){
  for(const x of [a,b]){x.c.tap(i);x.c.visitActions.children[0].onclick();if(x.c.w.eventChoices[i]?.requiresChoice)x.c.visitActions.children[0].onclick();x.c.visitModal.close();}
  await Promise.resolve();assert.deepEqual(snapshot(a),snapshot(b));assert.equal(tree(a),tree(b));
 }
 }
 result.checks.push('30 worlds x 30 facilities with F01/F02/D07/C03: choices, final outcomes, saves and rendered trees identical');
 for(const x of [a,b]){seedWorld(x,30,42);const old=x.memory[x.c.BoukenSchema.key],s=snapshot(x);x.c.failSave=true;assert.equal(x.c.persist(()=>{x.c.w.player.x=(x.c.w.player.x+1)%30;}),false);assert.equal(x.memory[x.c.BoukenSchema.key],old);assert.deepEqual(snapshot(x),s);x.c.failSave=false;x.c.render();}assert.equal(tree(a),tree(b));result.checks.push('save failure: persistent bytes unchanged, world/save rollback and render parity');
 fs.writeFileSync(path.join(__dirname,'results.json'),JSON.stringify(result,null,2));console.log('PASS',result.checks);
}
main().catch(e=>{console.error(e);process.exitCode=1;});
