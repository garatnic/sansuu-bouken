from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent.parent
src=(root/'baseline/bouken/world.html').read_text()
s=src.replace(' function render(){',' let renderKeys=[];\n function render(){',1)
s=s.replace('renderWorldParty();map.replaceChildren();actions.replaceChildren();','renderWorldParty();if(map.children.length!==w.terrain.length||map.dataset.worldSize!==w.width+"x"+w.height){map.replaceChildren();renderKeys=[];map.dataset.worldSize=w.width+"x"+w.height;}actions.replaceChildren();',1)
needle="facility=w.facility[i];const cell=document.createElement('button');"
replacement="""facility=w.facility[i];const key=JSON.stringify([tid,state,frontier,facility,!!w.visitedFacilities[i],treasure.has(i),people.has(i),guide&&guide.origin===i?guide.arrow:null,i===playerIndex(),i===playerIndex()?robotDriving:null,i===playerIndex()?w.partySnapshot:null]);if(renderKeys[i]===key&&map.children[i])return;renderKeys[i]=key;const cell=document.createElement('button');"""
assert s.count(needle)==1
s=s.replace(needle,replacement,1)
needle="cell.addEventListener('click',()=>tap(i));map.append(cell);"
assert s.count(needle)==1
s=s.replace(needle,"cell.addEventListener('click',()=>tap(i));if(map.children[i])map.children[i].replaceWith(cell);else map.append(cell);",1)
(root/'investigation/world-experiment.html').write_text(s)
# Snapshot inventory: every specification file is scanned, with size/hash and relevant paragraphs retained.
records=[]
for p in sorted((root/'baseline/bouken/siyou').rglob('*')):
 if not p.is_file():continue
 data=p.read_bytes();records.append({'path':str(p.relative_to(root/'baseline')),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(root/'investigation/spec-inventory.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
