// OPTIONAL, NOT EXECUTED HERE. Requires Playwright AND its Chromium executable on your machine.
// Uses a fresh isolated browser context and localhost only. Never opens production.
const {chromium}=require('playwright'),fs=require('fs'),path=require('path'),{spawn}=require('child_process');
const base=path.resolve(__dirname,'..'),origin='http://127.0.0.1:8769';
(async()=>{const server=spawn('python3',['-m','http.server','8769','--bind','127.0.0.1','--directory',path.join(base,'baseline')],{stdio:'ignore'});let browser;
 try{for(let k=0;k<50;k++){try{await fetch(origin);break;}catch{await new Promise(r=>setTimeout(r,100));}}
 browser=await chromium.launch({headless:true});const output=[];
 for(const variant of ['baseline','experiment'])for(const size of [5,10,20,30]){
 const ctx=await browser.newContext(),page=await ctx.newPage();let source=fs.readFileSync(variant==='baseline'?path.join(base,'baseline/bouken/world.html'):path.join(__dirname,'world-experiment.html'),'utf8');
 source=source.replace(" if(!Number.isInteger(w.lastExploredIndex))",` window.__facilityPerf={tap,render,getWorld:()=>w};\n if(!Number.isInteger(w.lastExploredIndex))`);
 await page.route('**/bouken/world.html',route=>route.fulfill({contentType:'text/html',body:source}));
 await page.goto(origin+'/bouken/world.html');await page.addScriptTag({url:origin+'/bouken/common/worldgen.js'});await page.addScriptTag({url:origin+'/bouken/common/party.js'});
 await page.evaluate(async n=>{const [t,f,counts,ch]=await Promise.all(['terrains','facilities','world_facility_counts','characters'].map(x=>BoukenMaster.load(x)));const s=BoukenSchema.makeInitialSave();s.tutorialStory.complete=true;s.worldsStarted=3;s.robotGrowth.discovery=3;s.robotGrowth.partyCapacity=5;for(const f of BoukenSchema.robotFeatures)s.robotGrowth.features[f.id]={stage:4};for(const c of ch)s.characters[c.id]=1;s.party=[53,11,42,5,1];s.world=BoukenWorldGen.generate(n,n,t,f,counts,[]);s.world.departureNumber=3;s.world.partySnapshot=s.party;s.world.partyBuffsSnapshot=BoukenParty.buffs(s.party,new Map(ch.map(c=>[c.id,c])));BoukenResult.start(s.world);BoukenSave.save(s);},size);
 await page.reload();await page.waitForFunction(()=>window.__facilityPerf);await page.locator('.world-header h1').click();await page.locator('#visitModal[open]').waitFor();await page.locator('#visitActions button').last().click();
 const data=await page.evaluate(async()=>{const out=[],p=window.__facilityPerf,paint=()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));const indices=p.getWorld().facility.flatMap((v,i)=>v?[i]:[]);
 for(const i of indices){let t=performance.now();p.tap(i);const openSync=performance.now()-t;await paint();const openPaint=performance.now()-t;const button=document.querySelector('#visitActions button');t=performance.now();button.click();const confirmSync=performance.now()-t;await paint();const confirmPaint=performance.now()-t;out.push({index:i,openSync,openPaint,confirmSync,confirmPaint});document.querySelector('#visitModal').close();await paint();}return out;});
 output.push({variant,size,data});await ctx.close();}
 fs.writeFileSync(path.join(__dirname,'browser-results.json'),JSON.stringify(output,null,2));
 }finally{await browser?.close();server.kill();}
})().catch(e=>{console.error(e);process.exitCode=1;});
